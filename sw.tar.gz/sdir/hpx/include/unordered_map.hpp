//  Copyright (C) 2014-2015 Hartmut Kaiser
//
//  Distributed under the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#if !defined(HPX_UNORDERED_MAP_NOV_11_2014_0857PM)
#define HPX_UNORDERED_MAP_NOV_11_2014_0857PM

#include <hpx/components/containers/unordered/unordered_map.hpp>

#endif


